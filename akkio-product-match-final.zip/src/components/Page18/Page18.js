import React from 'react';

const Page18 = ({ step,setStep}) => {
    return (
        <div>
            <div class="vertical-center" style={{width:'100%'}}>
	        	<center><p class="larger-font">Thanks for uploading your selfie and answering our questions!</p></center>

	        	<center><p class="larger-font">Your matches are:</p></center>

	        	<center class="final-match-style"><p class="even-larger-font">ID # Xx and ID # Yy.</p></center>

	        	<center><p class="larger-font">Keep an eye out for some free samples and an email with the subject line: 'Akkio Product Matching - Next Steps!' Be in touch soon.</p></center>

	        	<center><p class="larger-font">~ Akkio Team</p></center>

	        	<center><p><a href="https://akkiotech.com" class="home-button"><i class="fa fa-home" aria-hidden="true"></i></a></p></center>
	        </div>
        </div>
    );
};

export default Page18;